import drive_function from './external_fcuntions.js';
  

export default function content_add()
{
    return(
        <>
              <section>
                <h1 className="text-white">Oops, Content Management Page is  Under Maintenance</h1>
              </section>
        </>
    );
}