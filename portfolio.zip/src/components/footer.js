


export default function footer(){
    return(
        <>
            <footer style={{}} className="text-white border-top border-5 border-info">
                <h1 className="pt-1 ms-4" style={{fontSize:'30px', fontFamily: "'Bebas Neue', sans-serif"}}> Created By Group 2</h1>
            </footer>
        </>
    );
}