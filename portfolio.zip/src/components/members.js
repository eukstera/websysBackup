import '../components-css/members.css';
export default function members(){
    return(
        <>
           

          

        <section className='border border-bottom' style={{minHeight:'85vh', height:"auto"}}>

        <div className=' p-5 mt-5 d-flex flex-wrap  justify-content-around container  '>
                  


                  <div className='card '>

                  </div>
                  
                  
                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                  
                  <div className='card '>

                  </div>
                  
                  
                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                  
                  <div className='card '>

                  </div>
                  
                  
                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                   <div className='card '>

                  </div>

                
         </div>

         

        
        </section>
       
        </>
    );
}

